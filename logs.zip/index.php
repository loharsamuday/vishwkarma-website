<?php
$page_title = "Home";
require_once 'includes/db.php';
require_once 'includes/session.php';

// Fetch stats for the counter
$stats = [
    'members' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() + 1000,
    'brides' => $pdo->query("SELECT COUNT(*) FROM matrimony_profiles WHERE gender='Female'")->fetchColumn() + 500,
    'grooms' => $pdo->query("SELECT COUNT(*) FROM matrimony_profiles WHERE gender='Male'")->fetchColumn() + 500,
    'businesses' => $pdo->query("SELECT COUNT(*) FROM business_directory")->fetchColumn() + 200,
];

// Fetch latest gallery images
try {
    $latest_gallery = $pdo->query("
        SELECT ug.*, u.first_name, u.last_name 
        FROM user_gallery ug 
        JOIN users u ON ug.user_id = u.id 
        WHERE ug.status = 'approved' 
        ORDER BY ug.created_at DESC 
        LIMIT 4
    ")->fetchAll();
} catch (PDOException $e) {
    $latest_gallery = [];
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<!-- Hero Section -->
<section class="hero-section d-flex align-items-center justify-content-center text-center">
    <div class="container hero-content" data-aos="zoom-in">
        <h1 class="display-4 display-md-3 fw-bold mb-3 mb-md-4 text-white drop-shadow">Welcome to <span class="text-warning">Vishwakarma Samaj</span></h1>
        <p class="lead mb-4 mb-md-5 text-light fs-5 fs-md-4 drop-shadow">Connecting our community globally. Empowering lives through unity, education, and support.</p>
        <div class="hero-actions">
            <a href="register.php" class="btn btn-warning btn-lg px-4 px-md-5 py-3 fw-bold hero-btn">Join Community</a>
            <a href="matrimony.php" class="btn btn-outline-light btn-lg px-4 px-md-5 py-3 fw-bold hero-btn">Register Matrimony</a>
        </div>
    </div>
</section>

<!-- Quick Services -->
<section class="py-5 bg-light">
    <div class="container mt-4 mb-4">
        <div class="text-center mb-5" data-aos="fade-up">
            <h2 class="fw-bold section-title">Our <span class="text-warning">Services</span></h2>
        </div>
        <div class="row g-4">
            <!-- Service 1 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="100">
                <a href="matrimony.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-warning">
                            <i class="fa-solid fa-heart fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Matrimony</h4>
                        <p class="text-muted small">Find your perfect match within the community.</p>
                    </div>
                </a>
            </div>
            <!-- Service 2 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="200">
                <a href="business-directory.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-warning">
                            <i class="fa-solid fa-briefcase fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Business</h4>
                        <p class="text-muted small">Grow and support community businesses.</p>
                    </div>
                </a>
            </div>
            <!-- Service 3 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="300">
                <a href="jobs.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-warning">
                            <i class="fa-solid fa-user-tie fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Jobs</h4>
                        <p class="text-muted small">Find job opportunities and skilled workers.</p>
                    </div>
                </a>
            </div>
            <!-- Service 4 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="400">
                <a href="education.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-warning">
                            <i class="fa-solid fa-graduation-cap fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Education</h4>
                        <p class="text-muted small">Scholarships and career guidance.</p>
                    </div>
                </a>
            </div>
            <!-- Service 5 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="100">
                <a href="blood-bank.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-danger">
                            <i class="fa-solid fa-droplet fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Blood Bank</h4>
                        <p class="text-muted small">Donate and find blood donors in emergency.</p>
                    </div>
                </a>
            </div>
            <!-- Service 6 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="200">
                <a href="community-directory.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-warning">
                            <i class="fa-solid fa-users fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Directory</h4>
                        <p class="text-muted small">Connect with families and members.</p>
                    </div>
                </a>
            </div>
            <!-- Service 7 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="300">
                <a href="events.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-warning">
                            <i class="fa-regular fa-calendar-days fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Events</h4>
                        <p class="text-muted small">Stay updated on community gatherings.</p>
                    </div>
                </a>
            </div>
            <!-- Service 8 -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="400">
                <a href="gallery.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4">
                        <div class="service-icon mb-3 text-warning">
                            <i class="fa-solid fa-images fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">Gallery</h4>
                        <p class="text-muted small">Photos and videos of community events.</p>
                    </div>
                </a>
            </div>
            <!-- Service 9: Web Services -->
            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="100">
                <a href="web-services.php" class="text-decoration-none">
                    <div class="card service-card text-center p-4" style="border: 2px solid #ffc107;">
                        <div class="position-absolute top-0 start-50 translate-middle badge rounded-pill bg-danger shadow-sm">New</div>
                        <div class="service-icon mb-3 text-dark">
                            <i class="fa-solid fa-code fa-3x"></i>
                        </div>
                        <h4 class="text-dark fw-bold">IT & Web Services</h4>
                        <p class="text-muted small">Get your own website or portal built by us.</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Statistics Section -->
<section class="py-5 bg-warning text-dark stats-section text-center position-relative" data-aos="fade-up">
    <div class="container z-index-1 position-relative">
        <h2 class="mb-5 fw-bold text-white drop-shadow-sm">Samaj at a Glance</h2>
        <div class="row g-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-box p-4 bg-white rounded-4 shadow-sm hover-lift">
                    <h2 class="display-5 fw-bold text-warning mb-0 counter" data-target="<?= $stats['members'] ?>">0</h2>
                    <p class="text-muted fw-semibold mb-0 mt-2">Registered Members</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-box p-4 bg-white rounded-4 shadow-sm hover-lift">
                    <h2 class="display-5 fw-bold text-warning mb-0 counter" data-target="<?= $stats['brides'] ?>">0</h2>
                    <p class="text-muted fw-semibold mb-0 mt-2">Brides</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-box p-4 bg-white rounded-4 shadow-sm hover-lift">
                    <h2 class="display-5 fw-bold text-warning mb-0 counter" data-target="<?= $stats['grooms'] ?>">0</h2>
                    <p class="text-muted fw-semibold mb-0 mt-2">Grooms</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-box p-4 bg-white rounded-4 shadow-sm hover-lift">
                    <h2 class="display-5 fw-bold text-warning mb-0 counter" data-target="<?= $stats['businesses'] ?>">0</h2>
                    <p class="text-muted fw-semibold mb-0 mt-2">Business Owners</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Latest Gallery Section -->
<section class="py-5 bg-light">
    <div class="container my-5">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4 gap-3" data-aos="fade-right">
            <div>
                <h6 class="text-warning fw-bold text-uppercase tracking-wide">Community Showcase</h6>
                <h2 class="fw-bold mb-0">Latest <span class="text-warning">Gallery</span></h2>
            </div>
            <a href="gallery.php" class="btn btn-outline-dark fw-bold px-4">View All <i class="fa-solid fa-arrow-right ms-2"></i></a>
        </div>
        
        <div class="row g-4">
            <?php if (!empty($latest_gallery)): ?>
                <?php foreach ($latest_gallery as $index => $img): ?>
                    <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="<?= $index * 100 ?>">
                        <div class="card border-0 shadow-sm h-100 overflow-hidden">
                            <img src="uploads/gallery/<?= htmlspecialchars($img['image_path']) ?>" class="card-img-top hover-scale" alt="Gallery Image" style="height: 200px; object-fit: cover; transition: transform 0.3s ease;">
                            <div class="card-body py-2 px-3 text-center bg-white border-top">
                                <small class="text-muted fw-bold">By <?= htmlspecialchars($img['first_name'] . ' ' . $img['last_name']) ?></small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center py-4">
                    <p class="text-muted mb-3">No images uploaded yet.</p>
                    <a href="gallery.php" class="btn btn-warning fw-bold">Be the first to upload!</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="py-5 bg-white">
    <div class="container my-5">
        <div class="row align-items-center">
            <div class="col-md-6 mb-4 mb-md-0" data-aos="fade-right">
                <?php $about_img = (!empty($global_settings['image_home_about'])) ? BASE_URL . "uploads/banners/" . $global_settings['image_home_about'] : "https://placehold.co/600x400/2c3e50/f39c12?text=Lord+Vishwakarma"; ?>
                <img src="<?= htmlspecialchars($about_img) ?>" class="img-fluid rounded-4 shadow-lg hover-scale" alt="Vishwakarma Samaj" style="width: 100%; object-fit: cover;">
            </div>
            <div class="col-md-6 px-md-5" data-aos="fade-left">
                <h6 class="text-warning fw-bold text-uppercase tracking-wide">About Us</h6>
                <h2 class="fw-bold mb-4">Preserving Tradition, Embracing Progress</h2>
                <p class="text-muted mb-4" style="line-height: 1.8;">
                    The Vishwakarma Samaj has a rich history of craftsmanship, engineering, and architectural brilliance. Our community is dedicated to uplifting its members through mutual support, educational initiatives, and creating a strong network.
                </p>
                <p class="text-muted mb-4" style="line-height: 1.8;">
                    Join us in building a vibrant future while staying deeply rooted in our cultural heritage. Together we can achieve greatness.
                </p>
                <a href="about.php" class="btn btn-outline-warning fw-bold px-4 py-2 mt-2">Read More <i class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </div>
</section>

<!-- Trust Badges Section -->
<section class="py-4 bg-light border-top border-bottom border-warning">
    <div class="container text-center">
        <h5 class="fw-bold text-muted mb-4 text-uppercase tracking-wide">Why Trust Us?</h5>
        <div class="row g-4 justify-content-center">
            <div class="col-6 col-md-3" data-aos="zoom-in" data-aos-delay="100">
                <i class="fa-solid fa-shield-halved fa-3x text-success mb-2"></i>
                <h6 class="fw-bold mb-0">100% Secure</h6>
                <small class="text-muted">256-Bit SSL Encryption</small>
            </div>
            <div class="col-6 col-md-3" data-aos="zoom-in" data-aos-delay="200">
                <i class="fa-solid fa-user-check fa-3x text-primary mb-2"></i>
                <h6 class="fw-bold mb-0">Verified Profiles</h6>
                <small class="text-muted">Strict Manual Verification</small>
            </div>
            <div class="col-6 col-md-3" data-aos="zoom-in" data-aos-delay="300">
                <i class="fa-solid fa-lock fa-3x text-danger mb-2"></i>
                <h6 class="fw-bold mb-0">Privacy First</h6>
                <small class="text-muted">Complete Data Control</small>
            </div>
            <div class="col-6 col-md-3" data-aos="zoom-in" data-aos-delay="400">
                <i class="fa-solid fa-headset fa-3x text-info mb-2"></i>
                <h6 class="fw-bold mb-0">24/7 Support</h6>
                <small class="text-muted">Always Here to Help</small>
            </div>
        </div>
    </div>
</section>

<!-- Success Stories / Testimonials -->
<section class="py-5 bg-white">
    <div class="container my-5">
        <div class="text-center mb-5" data-aos="fade-up">
            <h6 class="text-warning fw-bold text-uppercase tracking-wide">Success Stories</h6>
            <h2 class="fw-bold section-title">What Our <span class="text-warning">Members Say</span></h2>
        </div>
        <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="4000">
            <div class="carousel-indicators" style="bottom: -50px;">
                <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="0" class="active bg-warning" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="1" class="bg-warning" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="2" class="bg-warning" aria-label="Slide 3"></button>
            </div>
            
            <div class="carousel-inner px-3 py-4">
                <!-- Slide 1 -->
                <div class="carousel-item active">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-6">
                            <div class="card border-0 shadow p-5 hover-card text-center" style="border-radius: 20px; border-top: 5px solid #ffc107 !important;">
                                <img src="https://ui-avatars.com/api/?name=R+S&background=random" class="rounded-circle mx-auto mb-3 shadow" width="80" height="80" alt="Avatar">
                                <h5 class="fw-bold mb-1">Rajesh Sharma</h5>
                                <div class="text-warning mb-3 fs-5">
                                    <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                                </div>
                                <p class="text-muted fst-italic fs-5">"I found my life partner through the Matrimony section. The profiles are 100% genuine and the verification process is top-notch. Highly recommended for our community!"</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="carousel-item">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-6">
                            <div class="card border-0 shadow p-5 hover-card text-center" style="border-radius: 20px; border-top: 5px solid #ffc107 !important;">
                                <img src="https://ui-avatars.com/api/?name=A+V&background=random" class="rounded-circle mx-auto mb-3 shadow" width="80" height="80" alt="Avatar">
                                <h5 class="fw-bold mb-1">Amit Vishwakarma</h5>
                                <div class="text-warning mb-3 fs-5">
                                    <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                                </div>
                                <p class="text-muted fst-italic fs-5">"Listed my carpentry business in the directory and started getting calls from our community members within a week. This platform is truly helping us grow together."</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slide 3 -->
                <div class="carousel-item">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-lg-6">
                            <div class="card border-0 shadow p-5 hover-card text-center" style="border-radius: 20px; border-top: 5px solid #ffc107 !important;">
                                <img src="https://ui-avatars.com/api/?name=S+P&background=random" class="rounded-circle mx-auto mb-3 shadow" width="80" height="80" alt="Avatar">
                                <h5 class="fw-bold mb-1">Sneha Panchal</h5>
                                <div class="text-warning mb-3 fs-5">
                                    <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i>
                                </div>
                                <p class="text-muted fst-italic fs-5">"The blood bank feature saved a relative's life during an emergency. The fact that the entire samaj is connected here gives a great sense of security and trust."</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev" style="width: 5%;">
                <span class="carousel-control-prev-icon bg-warning rounded-circle p-3" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next" style="width: 5%;">
                <span class="carousel-control-next-icon bg-warning rounded-circle p-3" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
</section>

<script>
    // Counter Animation
    document.addEventListener("DOMContentLoaded", () => {
        const counters = document.querySelectorAll('.counter');
        const speed = 200; 

        counters.forEach(counter => {
            const updateCount = () => {
                const target = +counter.getAttribute('data-target');
                const count = +counter.innerText;
                const inc = target / speed;

                if (count < target) {
                    counter.innerText = Math.ceil(count + inc);
                    setTimeout(updateCount, 15);
                } else {
                    counter.innerText = target;
                }
            };
            
            // Simple intersection observer to trigger when in view
            const observer = new IntersectionObserver((entries) => {
                if(entries[0].isIntersecting) {
                    updateCount();
                    observer.disconnect();
                }
            });
            observer.observe(counter);
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>
