<?php
$page_title = "Search Matches";
require_once 'includes/db.php';
require_once 'includes/session.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

// Build the query dynamically
$query = "
    SELECT m.id, m.gender, m.dob, m.education, m.profession, u.first_name, u.last_name, p.profile_pic, r.name as religion
    FROM matrimony_profiles m 
    JOIN users u ON m.user_id = u.id
    LEFT JOIN member_profiles p ON u.id = p.user_id
    LEFT JOIN religions r ON m.religion_id = r.id
    WHERE 1=1
";
$params = [];

if (isset($_GET['gender']) && !empty($_GET['gender'])) {
    $query .= " AND m.gender = ?";
    $params[] = $_GET['gender'];
}

if (isset($_GET['age_from']) && !empty($_GET['age_from'])) {
    $query .= " AND TIMESTAMPDIFF(YEAR, m.dob, CURDATE()) >= ?";
    $params[] = $_GET['age_from'];
}

if (isset($_GET['age_to']) && !empty($_GET['age_to'])) {
    $query .= " AND TIMESTAMPDIFF(YEAR, m.dob, CURDATE()) <= ?";
    $params[] = $_GET['age_to'];
}

if (isset($_GET['religion']) && !empty($_GET['religion'])) {
    if(is_numeric($_GET['religion'])) {
        $query .= " AND m.religion_id = ?";
        $params[] = $_GET['religion'];
    } else {
        $query .= " AND r.name = ?";
        $params[] = $_GET['religion'];
    }
}

$query .= " ORDER BY m.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$results = $stmt->fetchAll();
?>

<div class="bg-dark text-white py-4 text-center">
    <div class="container">
        <h2 class="fw-bold text-warning">Search Results</h2>
        <p class="mb-0">Found <?= count($results) ?> matching profile(s).</p>
    </div>
</div>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-12">
            <a href="matrimony.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-2"></i>Back to Search</a>
        </div>
    </div>
    
    <div class="row g-4">
        <?php if (empty($results)): ?>
            <div class="col-12 text-center text-muted">
                <div class="card card-custom p-5 border-0 shadow-sm">
                    <i class="fa-solid fa-search-minus fa-3x mb-3 text-warning"></i>
                    <h4>No profiles found matching your criteria.</h4>
                    <p>Try adjusting your search filters.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($results as $profile): 
                $age = date_diff(date_create($profile['dob']), date_create('today'))->y;
                $default_pic = $profile['gender'] == 'Male' ? 'https://placehold.co/150x150/2c3e50/white?text=Groom' : 'https://placehold.co/150x150/f39c12/white?text=Bride';
                $pic = $profile['profile_pic'] ? BASE_URL . "uploads/profile/" . $profile['profile_pic'] : $default_pic;
            ?>
            <div class="col-md-4 col-sm-6">
                <div class="card card-custom h-100 text-center p-3 border-0 shadow-sm hover-lift">
                    <img src="<?= htmlspecialchars($pic) ?>" class="rounded-circle mx-auto mb-3 border border-3 border-warning" alt="Profile" style="width: 120px; height: 120px; object-fit: cover;">
                    <h5 class="fw-bold mb-1"><?= htmlspecialchars($profile['first_name'] . ' ' . $profile['last_name']) ?></h5>
                    <p class="text-muted small mb-2">VISH-<?= str_pad($profile['id'], 5, '0', STR_PAD_LEFT) ?></p>
                    
                    <ul class="list-unstyled small text-start bg-light p-3 rounded mb-3">
                        <li><strong>Age:</strong> <?= $age ?> Yrs</li>
                        <li><strong>Religion:</strong> <?= htmlspecialchars($profile['religion'] ?? 'N/A') ?></li>
                        <li><strong>Education:</strong> <?= htmlspecialchars($profile['education'] ?? 'N/A') ?></li>
                        <li><strong>Profession:</strong> <?= htmlspecialchars($profile['profession'] ?? 'N/A') ?></li>
                    </ul>
                    <a href="profile.php?id=<?= $profile['id'] ?>" class="btn btn-outline-warning w-100 mt-auto">View Profile</a>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
