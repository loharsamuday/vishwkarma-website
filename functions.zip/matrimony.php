<?php
$page_title = "Matrimony";
require_once 'includes/db.php';
require_once 'includes/session.php';

// Fetch recent profiles
$stmt = $pdo->query("
    SELECT m.id, m.gender, m.dob, m.education, m.profession, u.first_name, u.last_name, u.last_active, p.profile_pic 
    FROM matrimony_profiles m 
    JOIN users u ON m.user_id = u.id
    LEFT JOIN member_profiles p ON u.id = p.user_id
    ORDER BY m.created_at DESC 
    LIMIT 6
");
$recent_profiles = $stmt->fetchAll();

// Fetch Matrimony Settings
$settings_stmt = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('is_matrimony_paid', 'matrimony_free_promo_message')");
$matrimony_settings = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
$is_paid_mode = isset($matrimony_settings['is_matrimony_paid']) && $matrimony_settings['is_matrimony_paid'] == '1';
$promo_message = $matrimony_settings['matrimony_free_promo_message'] ?? 'Hurry! Register now for free!';

// Check if logged in user is already registered in matrimony
$has_matrimony_profile = false;
if (isLoggedIn()) {
    $stmt_check = $pdo->prepare("SELECT id FROM matrimony_profiles WHERE user_id = ?");
    $stmt_check->execute([$_SESSION['user_id']]);
    if ($stmt_check->fetch()) {
        $has_matrimony_profile = true;
    }
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<!-- Header Banner -->
<?php 
$global_settings = function_exists('getGlobalSettings') ? getGlobalSettings() : [];
$banner_matrimony = (!empty($global_settings['banner_matrimony'])) ? BASE_URL . "uploads/banners/" . $global_settings['banner_matrimony'] : "https://placehold.co/1920x400/2c3e50/f39c12?text=Matrimony";
?>
<div class="bg-dark text-white py-5 text-center" style="background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('<?= htmlspecialchars($banner_matrimony) ?>') center/cover;">
    <div class="container" data-aos="zoom-in">
        <h1 class="display-4 fw-bold text-warning">Find Your Perfect Match</h1>
        <p class="lead">Thousands of verified profiles from the Vishwakarma Samaj.</p>
        <?php if(!isLoggedIn()): ?>
            <a href="register.php" class="btn btn-warning btn-lg mt-3 fw-bold">Register Free Profile</a>
        <?php else: ?>
            <a href="dashboard.php" class="btn btn-warning btn-lg mt-3 fw-bold">My Matrimony Dashboard</a>
        <?php endif; ?>
        <div class="mt-4" data-aos="fade-up" data-aos-delay="100">
            <span class="badge bg-dark bg-opacity-50 border border-secondary px-3 py-2 fs-6 rounded-pill text-light"><i class="fa-solid fa-lock text-success me-2"></i>100% Privacy Guaranteed &middot; Strictly Verified Profiles</span>
        </div>
    </div>
</div>

<?php if (!$is_paid_mode && !$has_matrimony_profile): ?>
<!-- Free Promo Banner -->
<div class="bg-warning text-dark py-3 text-center border-bottom border-dark border-3 shadow-sm" data-aos="fade-down">
    <div class="container d-flex flex-column flex-md-row justify-content-center align-items-center gap-3">
        <h5 class="fw-bold mb-0"><i class="fa-solid fa-bullhorn text-danger fa-beat me-2"></i> <?= htmlspecialchars($promo_message) ?></h5>
        <?php if(!isLoggedIn()): ?>
            <a href="register.php" class="btn btn-dark btn-sm fw-bold px-4 rounded-pill">Claim Free Offer <i class="fa-solid fa-arrow-right ms-1"></i></a>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<div class="container py-5">
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card card-custom p-4 shadow-sm" data-aos="fade-up">
                <h4 class="text-warning mb-4 fw-bold">Quick Search</h4>
                <form action="search.php" method="GET">
                    <div class="row g-3">
                        <div class="col-md-2">
                            <label class="form-label">Looking for</label>
                            <select name="gender" class="form-select">
                                <option value="Female">Bride</option>
                                <option value="Male">Groom</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Age From</label>
                            <select name="age_from" class="form-select">
                                <?php for($i=18; $i<=60; $i++) echo "<option value='$i'>$i</option>"; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Age To</label>
                            <select name="age_to" class="form-select">
                                <?php for($i=18; $i<=60; $i++) echo "<option value='$i' ".($i==30 ? "selected" : "").">$i</option>"; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Religion</label>
                            <select name="religion" class="form-select">
                                <option value="">Any</option>
                                <option value="Hindu">Hindu</option>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-warning w-100 fw-bold">Search Now <i class="fa-solid fa-search ms-1"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Recent Profiles -->
    <h3 class="mb-4 fw-bold" data-aos="fade-right">Recently Added Profiles</h3>
    <div class="row g-4">
        <?php if (empty($recent_profiles)): ?>
            <div class="col-12 text-center text-muted">
                <p>No profiles found. Be the first to <a href="register.php" class="text-warning">register</a>!</p>
            </div>
        <?php else: ?>
            <?php foreach ($recent_profiles as $index => $profile): 
                $age = date_diff(date_create($profile['dob']), date_create('today'))->y;
                $default_pic = $profile['gender'] == 'Male' ? 'https://placehold.co/150x150/2c3e50/white?text=Groom' : 'https://placehold.co/150x150/f39c12/white?text=Bride';
                $pic = $profile['profile_pic'] ? BASE_URL . "uploads/profile/" . $profile['profile_pic'] : $default_pic;
            ?>
            <div class="col-md-4 col-sm-6" data-aos="fade-up" data-aos-delay="<?= $index * 100 ?>">
                <div class="card card-custom h-100 text-center p-3 position-relative">
                    <?php if(isUserOnline($profile['last_active'])): ?>
                        <span class="position-absolute top-0 start-100 translate-middle p-2 bg-success border border-light rounded-circle" style="z-index: 2;" title="Online Now">
                            <span class="visually-hidden">New alerts</span>
                        </span>
                    <?php endif; ?>
                    <img src="<?= htmlspecialchars($pic) ?>" class="rounded-circle mx-auto mb-3 border border-3 border-warning" alt="Profile" style="width: 120px; height: 120px; object-fit: cover;">
                    <h5 class="fw-bold mb-1">
                        <?= htmlspecialchars($profile['first_name'] . ' ' . $profile['last_name']) ?>
                    </h5>
                    <p class="text-muted small mb-2">VISH-<?= str_pad($profile['id'], 5, '0', STR_PAD_LEFT) ?></p>
                    
                    <ul class="list-unstyled small text-start bg-light p-3 rounded mb-3">
                        <li><strong>Age:</strong> <?= $age ?> Yrs</li>
                        <li><strong>Education:</strong> <?= htmlspecialchars($profile['education'] ?? 'N/A') ?></li>
                        <li><strong>Profession:</strong> <?= htmlspecialchars($profile['profession'] ?? 'N/A') ?></li>
                    </ul>
                    <a href="profile.php?id=<?= $profile['id'] ?>" class="btn btn-outline-warning w-100 mt-auto">View Profile</a>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
