<?php
// api/matrimony_search_ajax.php
require_once '../config/config.php';
// require_once '../includes/db.php'; // DB Connection

header('Content-Type: application/json');

// Get search params
$gender = $_GET['base_gender'] ?? '';
$state = $_GET['base_state'] ?? '';
$city = $_GET['base_city'] ?? '';
$age_min = $_GET['age_min'] ?? '';
$age_max = $_GET['age_max'] ?? '';
$verified_only = isset($_GET['verified_only']) ? true : false;
$sort = $_GET['sort'] ?? 'recent';

// Here we would build a SQL query based on the parameters
// e.g., SELECT * FROM ent_matrimony_profiles p JOIN ... WHERE p.gender = ? ...

// Mockup data for demonstration
$profiles = [
    [
        'name' => 'Rahul Vishwakarma',
        'age' => 28,
        'height' => '5\'8"',
        'city' => 'Patna',
        'occupation' => 'Software Engineer',
        'income' => '10L+',
        'verified' => true,
        'premium' => true,
        'slug' => 'rahul-vishwakarma-123',
        'score' => 98
    ],
    [
        'name' => 'Amit Vishwakarma',
        'age' => 30,
        'height' => '5\'10"',
        'city' => 'Patna',
        'occupation' => 'Government Job',
        'income' => '8L+',
        'verified' => true,
        'premium' => false,
        'slug' => 'amit-vishwakarma-456',
        'score' => 90
    ],
    [
        'name' => 'Priya Vishwakarma',
        'age' => 26,
        'height' => '5\'4"',
        'city' => 'Patna',
        'occupation' => 'Doctor',
        'income' => '15L+',
        'verified' => true,
        'premium' => true,
        'slug' => 'priya-vishwakarma-789',
        'score' => 100
    ]
];

// Simple filter logic for mockup
$filtered = [];
foreach ($profiles as $p) {
    if ($gender === 'Female' && $p['name'] !== 'Priya Vishwakarma') continue;
    if ($gender === 'Male' && $p['name'] === 'Priya Vishwakarma') continue;
    
    if ($age_min && $p['age'] < $age_min) continue;
    if ($age_max && $p['age'] > $age_max) continue;
    
    if ($verified_only && !$p['verified']) continue;
    
    $filtered[] = $p;
}

$html = '';
foreach ($filtered as $p) {
    // Generate profile card HTML
    $html .= '
    <div class="col-md-6 col-lg-4">
        <div class="card profile-card h-100">
            <div class="card-img-top bg-light" style="height:200px; display:flex; align-items:center; justify-content:center;">
                <img src="' . BASE_URL . 'assets/images/default-avatar.png" alt="' . $p['name'] . '" style="max-height:100%;">
            </div>
            <div class="card-body">
                <h5 class="card-title text-danger">' . $p['name'] . '</h5>
                <p class="card-text text-muted mb-1">
                    <small>
                        ' . $p['age'] . ' Yrs, ' . $p['height'] . '<br>
                        ' . $p['city'] . '<br>
                        ' . $p['occupation'] . '
                    </small>
                </p>
                <div class="mb-2">
                    ' . ($p['verified'] ? '<span class="badge bg-success">Verified</span>' : '') . '
                    ' . ($p['premium'] ? '<span class="badge bg-warning text-dark">Premium</span>' : '') . '
                </div>
                <div class="progress mb-3" style="height: 10px;" title="Profile Completeness">
                  <div class="progress-bar bg-info" role="progressbar" style="width: ' . $p['score'] . '%" aria-valuenow="' . $p['score'] . '" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <a href="' . BASE_URL . 'brides/bihar/patna/' . $p['slug'] . '" class="btn btn-outline-danger btn-sm w-100">View Profile</a>
            </div>
        </div>
    </div>';
}

echo json_encode([
    'total' => count($filtered),
    'html' => $html
]);
?>
