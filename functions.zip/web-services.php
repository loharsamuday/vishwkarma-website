<?php
$page_title = "Web Development Services";
require_once 'includes/db.php';
require_once 'includes/session.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

// Get WhatsApp Number for CTA
if (!isset($global_settings)) {
    $global_settings = function_exists('getGlobalSettings') ? getGlobalSettings() : [];
}
$whatsapp_number = $global_settings['whatsapp_number'] ?? ($global_settings['contact_phone'] ?? '');
$whatsapp_clean = preg_replace('/[^0-9]/', '', $whatsapp_number);
$whatsapp_link = !empty($whatsapp_clean) ? "https://wa.me/" . $whatsapp_clean . "?text=" . urlencode("Hello, I am interested in getting a website developed.") : "contact.php";
?>

<style>
    .web-hero {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        padding: 100px 0;
        position: relative;
        overflow: hidden;
    }
    .web-hero::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(243,156,18,0.1) 0%, rgba(0,0,0,0) 60%);
        z-index: 1;
        animation: pulse-bg 10s infinite alternate;
    }
    @keyframes pulse-bg {
        0% { transform: scale(1); }
        100% { transform: scale(1.2); }
    }
    .web-hero-content {
        position: relative;
        z-index: 2;
    }
    .service-card-web {
        transition: all 0.3s ease;
        border-radius: 15px;
        border: 1px solid rgba(0,0,0,0.05);
    }
    .service-card-web:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        border-color: #ffc107;
    }
    .feature-icon-box {
        width: 70px;
        height: 70px;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 30px;
        margin-bottom: 20px;
    }
</style>

<!-- Hero Section -->
<section class="web-hero text-center text-white">
    <div class="container web-hero-content" data-aos="zoom-in">
        <span class="badge bg-warning text-dark fs-6 px-4 py-2 rounded-pill mb-4"><i class="fa-solid fa-code me-2"></i> Professional IT & Web Services</span>
        <h1 class="display-3 fw-bold mb-4 drop-shadow">Need a <span class="text-warning">Website</span> for Your Business?</h1>
        <p class="lead mb-5 fs-4 text-light opacity-75" style="max-width: 800px; margin: 0 auto;">We design and develop high-quality, fast, and secure websites tailored to your specific needs. From e-commerce to custom portals, we build digital experiences that drive growth.</p>
        
        <a href="<?= $whatsapp_link ?>" <?= !empty($whatsapp_clean) ? 'target="_blank"' : '' ?> class="btn btn-warning btn-lg px-5 py-3 fw-bold rounded-pill shadow-lg hover-scale">
            <i class="fa-brands fa-whatsapp fs-4 me-2 align-middle"></i> Chat With Developer
        </a>
        <p class="mt-4 text-light opacity-50 small"><i class="fa-solid fa-shield-halved me-1"></i> Trusted by the Community &middot; 100% Satisfaction Guaranteed</p>
    </div>
</section>

<!-- Services Offered -->
<section class="py-5 bg-light">
    <div class="container my-5">
        <div class="text-center mb-5" data-aos="fade-up">
            <h6 class="text-warning fw-bold text-uppercase tracking-wide">Our Expertise</h6>
            <h2 class="fw-bold section-title">What We <span class="text-warning">Build</span></h2>
        </div>
        
        <div class="row g-4">
            <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                <div class="card service-card-web bg-white p-4 h-100">
                    <div class="feature-icon-box bg-primary bg-opacity-10 text-primary">
                        <i class="fa-solid fa-store"></i>
                    </div>
                    <h4 class="fw-bold mb-3">E-Commerce Stores</h4>
                    <p class="text-muted">Start selling online with fully functional, secure, and easy-to-manage e-commerce websites with payment gateway integration.</p>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                <div class="card service-card-web bg-white p-4 h-100">
                    <div class="feature-icon-box bg-success bg-opacity-10 text-success">
                        <i class="fa-solid fa-building"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Business Websites</h4>
                    <p class="text-muted">Professional portfolio and corporate websites to showcase your services, build trust, and attract new clients.</p>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                <div class="card service-card-web bg-white p-4 h-100">
                    <div class="feature-icon-box bg-warning bg-opacity-10 text-warning">
                        <i class="fa-solid fa-users"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Community Portals</h4>
                    <p class="text-muted">Custom platforms like Matrimony, Job portals, and Directories tailored for your community.</p>
                </div>
            </div>
            
            <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                <div class="card service-card-web bg-white p-4 h-100">
                    <div class="feature-icon-box bg-danger bg-opacity-10 text-danger">
                        <i class="fa-solid fa-map-location-dot"></i>
                    </div>
                    <h4 class="fw-bold mb-3">Google Map Listing</h4>
                    <p class="text-muted">Get your business verified on Google My Business. Rank higher on local searches and attract more customers.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Why Choose Us -->
<section class="py-5 bg-white">
    <div class="container my-5">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade-right">
                <img src="https://placehold.co/600x500/2c3e50/f39c12?text=Web+Development" class="img-fluid rounded-4 shadow-lg" alt="Web Development">
            </div>
            <div class="col-lg-6 px-lg-5" data-aos="fade-left">
                <h6 class="text-warning fw-bold text-uppercase tracking-wide">Why Choose Us?</h6>
                <h2 class="fw-bold mb-4">Quality Code, Affordable Price</h2>
                
                <div class="d-flex mb-4">
                    <div class="text-warning fs-3 me-3"><i class="fa-solid fa-rocket"></i></div>
                    <div>
                        <h5 class="fw-bold">Lightning Fast Performance</h5>
                        <p class="text-muted">We build highly optimized websites that load quickly and rank better on Google (SEO Friendly).</p>
                    </div>
                </div>
                
                <div class="d-flex mb-4">
                    <div class="text-success fs-3 me-3"><i class="fa-solid fa-mobile-screen-button"></i></div>
                    <div>
                        <h5 class="fw-bold">100% Mobile Responsive</h5>
                        <p class="text-muted">Your website will look perfect and function flawlessly on smartphones, tablets, and desktops.</p>
                    </div>
                </div>
                
                <div class="d-flex mb-4">
                    <div class="text-primary fs-3 me-3"><i class="fa-solid fa-handshake-angle"></i></div>
                    <div>
                        <h5 class="fw-bold">Reliable Support</h5>
                        <p class="text-muted">Being from the community, we ensure transparent communication, affordable pricing, and long-term support.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-5 bg-warning text-dark text-center">
    <div class="container my-4" data-aos="zoom-in">
        <h2 class="fw-bold mb-3">Ready to Bring Your Idea to Life?</h2>
        <p class="lead mb-4 fw-semibold opacity-75">Let's discuss your project and get a free quotation today.</p>
        <a href="<?= $whatsapp_link ?>" <?= !empty($whatsapp_clean) ? 'target="_blank"' : '' ?> class="btn btn-dark btn-lg px-5 py-3 fw-bold rounded-pill shadow-lg hover-scale">
            <i class="fa-brands fa-whatsapp fs-4 me-2 align-middle text-success"></i> Message on WhatsApp
        </a>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
